#!/bin/bash

# Verificar si como argumento se pasa la palabra "help"
if [ "$1" == "-help" ]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Este script genera un backup comprimido (.tar.gz) del directorio origen"
	echo "y lo guarda en el destino con nombre nombre_bkp_YYYYMMDD.tar.gz"
	exit 0

# Valida si hay dos argumentos
elif [ "$#" -ne 2 ]; then
	echo "Error: Se requieren dos argumentos: origen y destino"
	echo "Use -help para mas informacion"
	exit 1
fi

# Validar que directorios de origen y destino esten disponibles
if [ ! -d "$1" ]; then
	echo "Error: El directorio de origen '$1' no existe"
	exit 1
elif [ ! -d "$2" ]; then
	echo "Error: El directorio de destino '$2' no existe"
	exit 1
fi

# Fecha en formato correspondiente
FECHA=$(date +%Y%m%d)

#Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

#Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

#Verificar que se creo correctamente
if [ -f "$2/$BACKUP" ]; then
	echo "Backup creado exitosamente: $2/$BACKUP"
else
	echo "Error: El backup no se creo correctamente"
	exit 1
fi
